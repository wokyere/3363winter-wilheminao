                                        PHP LOGIN AND LOGOUT WITH SERVER-SIDE VALIDATION

                                                    PROJECT DESCRIPTION

My project implements a basic login and logout system using PHP, server-side validation, and sessions. Only logged-in users can access a protected dashboard page. Users who are not logged in are automatically redirected to the login page.

                                                         FEATURES
1. It includes a login form that submits user credentials using the POST method.
2. Server-side validation for required fields (username and password)  
3. Session management to track logged-in users  
4. Protected dashboard page accessible only after login  
5. Logout functionality that destroys the session and cookies  

                                                      SETUP INSTRUCTIONS

1. Install XAMPP, Start it and start Apache.

2. Go to the XAMPP 'htdocs' folder: C:\xampp\htdocs\

3. Create this folder path:

 C:\xampp\htdocs\3363winter\lab03\

4. Open VS CODE. Open the lab03 folder and create these files:
index.php
login.php
auth.php
dashboard.php
logout.php
styles.css
README.md  

4. Open a browser and type this in the address bar:
    http://localhost/3363winter/lab03/login.php


                                                  HOW TO TEST: TESTING CHECKLIST

   Test URL:   http://localhost/3363winter/lab03/

1. Open a web browser and type in the test URL, this will send you automatically to the login page

2. Use the demo credentials to log in:  
- Username: student  
- Password: Lab03!  

3. After loggging in:  
- You should see the dashboard page with your username and login time.  
- Try refreshing login.php— it should redirect you to the dashboard automatically.  

4. Logout:  
- Click the logout link or visit logout.php
- You will go back to the login page and your session ends. 
Ensure the session is destroyed and you are redirected back to login.php


5. i. Submit the form with empty fields it will show error messages

   ii. Enter the wrong username or password shows "Invalid username or password"

   iii. Enter the correct login details, it sends the user to the dashboard and shows the username and login time

    iv. Click the logout link, this returns the user to the login page and ends the session

    v. Try to open the dashboard after logging out, this sends the user back to the login page


                                                  Your Demo Credentials

Username: student
Password: Lab03!

                                             File Responsibilities 

index.php – Redirects users to the login page

auth.php – Starts sessions and provides require_login() for page protection

login.php – Displays form, validates input, authenticates, and sets sessions  

dashboard.php – Protected page displaying session data

logout.php – Ends the session securely and redirects to login

styles.css – Basic layout and form styling

                                                   Reflection

This lab taught me how PHP sessions track authentication across multiple pages. I also learned how server-side validation ensures users enter required fields and how to protect pages from unauthorized access. I practiced redirecting users after login or logout to maintain a secure workflow.  

All in all, I realized that a very tiny little mistake like a missing semicolon, can break the entire project so i learnt attention to detail is very important.