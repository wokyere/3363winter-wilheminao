# Lab 04 — MySQL Database Design

Name: Wilhemina Maame Ahema Aseda Okyere  
Date: 2026-01-27

## What I submitted
- index.php  
- lab04_wilheminaokyere.sql  
- README.md  

## Database 
Database name: lab04_wilheminaokyere   
Table 1 (parent):  customers
Table 2 (child):  orders 
Primary key (Table 1): customer_id  
Foreign key (Table 2): customer_id

## Data 
Rows in Table 1:3 
Rows in Table 2:3

## JOIN query I ran 
```sql 
SELECT c.customer_id, c.first_name, c.last_name, c.email,
       o.order_id, o.order_date, o.total_amount, o.status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC;
