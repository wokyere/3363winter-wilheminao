# Lab 06 — PHP Web Security & Sessions (Secure Notes) 
**Student Name:** _Wilhemina Maame Ahema Aseda Okyere_______________ 
**Date:** ___12 February 2026_____________

## 1) What I built (1–2 sentences) 
I built a secure PHP notes web application with user registration, login authentication, role-based access control, session management, and protection against SQL injection and XSS attacks._________________________________________________________________   
____________________________________________________________________ 
## 2) How to run my lab 
**Database name:** `lab06_wilhemina'   
**Start page URL:**  
Steps: 
1. Start XAMPP (Apache + MySQL) 
2. Open phpMyAdmin and create my database 
3. Run the Lab06 SQL to create tables: `users`, `notes` 
4. Update `app/db.php` with my DB name 
5. Open the start page URL above 

## 3) Security features checklist: 

a. Register a new user (show password_hash in DB). 
b. Login (show session created, session ID changes due to session_regenerate_id). 
c. Open dashboard while logged out -> redirect to login. 
d. Create a note with XSS payload (`<script>alert('xss')</script>`) confirm it does NOT execute. 
e. Show session timeout by waiting (or temporarily set f. SESSION_TIMEOUT = 10 seconds). 
f. Show admin page returns 403 for normal user; allow access for admin. 

## 4) Test Results (PASS/FAIL) - Register works: __PASS______ - Login works (correct password): ___PASS_____ - Login fails (wrong password): _PASS_______ - Dashboard redirects when logged out: ___PASS_____ - Create note works: __PASS______ - XSS test does NOT run (`<script>alert('xss')</script>`): _PASS_______ - Admin page (user gets 403): ____PASS____ - Admin page (admin can view): ___PASS_____ - Session timeout works: ___PASS_____ ]

## 5) Reflection: what I have learned from Lab 06 (3-5 sentences) 
This lab showed me that secure login systems require much more than just checking a password. I learnt what a session timeout is it logs users out after inactivity to reduce risk. I also learnt that to prevent SQL injection you have to use prepared statements (prepare() + execute()), which separates SQL code from user input. This blocks injected SQL from form fields.