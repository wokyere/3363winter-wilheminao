<?php 
declare(strict_types=1); 
 
require_once __DIR__ . "/../app/security.php"; 
require_once __DIR__ . "/../app/db.php"; 
require_once __DIR__ . "/../app/auth.php"; 
security_headers(); 
 
enforce_session_timeout(); 
require_login(); 
 
$errors = []; 
$title = ""; 
$content = ""; 
 
if ($_SERVER["REQUEST_METHOD"] === "POST") { 
  $title = clean_string($_POST["title"] ?? ""); 
  $content = clean_string($_POST["content"] ?? ""); 
 // STUDENT TODO: Validate rules: title required (max 120), content required 
  if ($title === "") $errors[] = "Title is required."; 
  if (strlen($title) > 120) $errors[] = "Title must be 120 characters or less."; 
  if ($content === "") $errors[] = "Content is required."; 
 
  if (!$errors) { 
    $user_id = (int)$_SESSION["user_id"]; 
 
    // STUDENT TODO: Insert note using prepared statement 
    $stmt = $pdo->prepare("INSERT INTO notes (user_id, title, content) VALUES (?, ?, 
?)"); 
    $stmt->execute([$user_id, $title, $content]); 
 
    header("Location: dashboard.php"); 
    exit; 
  } 
} 
?> 
<!doctype html> 
<html lang="en"> 
<head> 
  <meta charset="utf-8"> 
  <title>Create Note</title> 
  <link rel="stylesheet" href="style.css">  
</head> 
<body> 
    <div class="wrapper">  
  <h1>Create Note</h1> 
 
  <?php if ($errors): ?> 
    <ul> 
      <?php foreach ($errors as $err): ?> 
        <li><?= e($err) ?></li> 
      <?php endforeach; ?> 
    </ul> 
  <?php endif; ?> 
 
  <form method="post" novalidate> 
    <label>Title: 
      <input type="text" name="title" maxlength="120" value="<?= e($title) ?>" 
required> 
    </label> 
    <br><br> 
    <label>Content:<br> 
      <textarea name="content" rows="6" cols="50" required><?= e($content) 
?></textarea> 
    </label> 
    <br><br> 
    <button type="submit">Save</button> 
  </form> 
 
  <!-- STUDENT TODO (JS): Add a client-side check that title/content are not blank 
(UX only). --> 
 <p><a href="dashboard.php">Back to Dashboard</a></p> 
 </div> 
</body> 
</html>
